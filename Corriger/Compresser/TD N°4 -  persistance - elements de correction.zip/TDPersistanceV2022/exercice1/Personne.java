package miage.TDPersistanceV2022.exercice1;


import java.io.Serializable;


public class Personne implements Serializable {
	
	private static final long serialVersionUID = 123L;
	
	private String nom;
	private String prenom; // 1b: renommer prenom en prenom1 une fois la sauvegarde faite et recharger les donn�es du fichier
	private int age;
	private Adresse adresse; 
	//public String prenom2; // 1b: ajouter prenom2 une fois la sauvegarde faite et recharger les donn�es du fichier
	
	public Personne() {
		System.out.println("Constructeur par d�faut de personne");
		// 1.b
		//prenom2 = "nouveau"; // on garde le m�me serialVersionUID et l'ajout de "prenom2" ne pose pas de probl�me
		// par contre le renommage de "prenom" en "prenom1" d�clenche une exception (non compatibilit� malgr� un serialVersion UID identique.
	}
	
	public Personne (String n, String p, int a) {
		nom = n;
		prenom = p;
		age = a;
	}
           
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Adresse getAdresse() {
		return adresse;
	}
	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

}
