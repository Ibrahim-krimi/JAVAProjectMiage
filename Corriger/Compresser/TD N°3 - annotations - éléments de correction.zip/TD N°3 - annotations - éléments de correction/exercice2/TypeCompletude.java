package miage.TDAnnotations.exercice2;

public enum TypeCompletude {
    Partial,
    Full,
    Finalized
}
